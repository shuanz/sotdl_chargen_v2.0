# -*- coding: utf-8 -*-
import dice


class Roll:
    def a_dice(dices):
        return str(int(dice.roll(dices)))
